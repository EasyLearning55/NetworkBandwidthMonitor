﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.NICComboBox = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.UploadLabel = New System.Windows.Forms.Label()
        Me.DownloadLabel = New System.Windows.Forms.Label()
        Me.BandwidthUpdateTimer = New System.Windows.Forms.Timer(Me.components)
        Me.TotalDLLabel = New System.Windows.Forms.Label()
        Me.TotalUploadLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'NICComboBox
        '
        Me.NICComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.NICComboBox.FormattingEnabled = True
        Me.NICComboBox.Location = New System.Drawing.Point(2, 1)
        Me.NICComboBox.Name = "NICComboBox"
        Me.NICComboBox.Size = New System.Drawing.Size(26, 21)
        Me.NICComboBox.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.Label1.Location = New System.Drawing.Point(34, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(22, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "U :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.Label2.Location = New System.Drawing.Point(190, 2)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(22, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "D :"
        '
        'UploadLabel
        '
        Me.UploadLabel.AutoSize = True
        Me.UploadLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.UploadLabel.ForeColor = System.Drawing.SystemColors.GrayText
        Me.UploadLabel.Location = New System.Drawing.Point(63, 3)
        Me.UploadLabel.Name = "UploadLabel"
        Me.UploadLabel.Size = New System.Drawing.Size(42, 15)
        Me.UploadLabel.TabIndex = 1
        Me.UploadLabel.Text = "0 KB/s"
        '
        'DownloadLabel
        '
        Me.DownloadLabel.AutoSize = True
        Me.DownloadLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.DownloadLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.DownloadLabel.Location = New System.Drawing.Point(226, 3)
        Me.DownloadLabel.Name = "DownloadLabel"
        Me.DownloadLabel.Size = New System.Drawing.Size(42, 15)
        Me.DownloadLabel.TabIndex = 1
        Me.DownloadLabel.Text = "0 KB/s"
        '
        'BandwidthUpdateTimer
        '
        Me.BandwidthUpdateTimer.Enabled = True
        Me.BandwidthUpdateTimer.Interval = 1000
        '
        'TotalDLLabel
        '
        Me.TotalDLLabel.AutoSize = True
        Me.TotalDLLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.TotalDLLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TotalDLLabel.Location = New System.Drawing.Point(303, 3)
        Me.TotalDLLabel.Name = "TotalDLLabel"
        Me.TotalDLLabel.Size = New System.Drawing.Size(33, 15)
        Me.TotalDLLabel.TabIndex = 1
        Me.TotalDLLabel.Text = "0 KB"
        '
        'TotalUploadLabel
        '
        Me.TotalUploadLabel.AutoSize = True
        Me.TotalUploadLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.TotalUploadLabel.Location = New System.Drawing.Point(116, 3)
        Me.TotalUploadLabel.Name = "TotalUploadLabel"
        Me.TotalUploadLabel.Size = New System.Drawing.Size(33, 15)
        Me.TotalUploadLabel.TabIndex = 1
        Me.TotalUploadLabel.Text = "0 KB"
        '
        'mainForm
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.ClientSize = New System.Drawing.Size(379, 25)
        Me.Controls.Add(Me.DownloadLabel)
        Me.Controls.Add(Me.UploadLabel)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TotalUploadLabel)
        Me.Controls.Add(Me.TotalDLLabel)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.NICComboBox)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Dim screenWidth As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim screenHeight As Integer = Screen.PrimaryScreen.Bounds.Height
        Me.Location = New System.Drawing.Point(0, screenHeight - 64)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(9999, 9999)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(8, 5)
        Me.Name = "mainForm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Bandwidth"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents NICComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents UploadLabel As System.Windows.Forms.Label
    Friend WithEvents DownloadLabel As System.Windows.Forms.Label
    Friend WithEvents BandwidthUpdateTimer As System.Windows.Forms.Timer
    Friend WithEvents TotalDLLabel As System.Windows.Forms.Label
    Friend WithEvents TotalUploadLabel As System.Windows.Forms.Label

End Class
